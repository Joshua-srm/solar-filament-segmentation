Put the downloaded model weights in this directory.
Expected filename:
solar_filament_yolo11n_seg_best.pt

Download the model from the Kaggle notebook's Output panel. It is not bundled
with this starter project. Do not commit the large model weight file to a
public Git repository unless you have checked the relevant competition/data
terms and decided it is appropriate.
