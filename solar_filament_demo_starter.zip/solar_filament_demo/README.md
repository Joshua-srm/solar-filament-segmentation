# Solar Filament Detection & Segmentation

A student computer-vision project that predicts solar-filament instance masks in an uploaded solar image using a fine-tuned YOLO11n segmentation model.

## Current results

- Model: YOLO11n instance segmentation
- Training setup: 600 images, 4,336 annotated instances; 107 validation images with 873 annotated instances
- Training configuration: 25 epochs, image size 1024, batch size 4, Tesla T4 GPU
- Validation box metrics: precision 0.614, recall 0.588, mAP@50 0.612, mAP@50–95 0.345
- Validation mask metrics: precision 0.642, recall 0.572, mAP@50 0.622, mAP@50–95 0.222
- First accepted competition submission: official score 0.26

Do not compare the official competition score directly with the detection mAP metrics; they evaluate different things. The initial submission needed pixel-level overlap correction because the competition disallows overlapping instance masks.

## 1. Install Python

Use a 64-bit Python 3.11 environment on Windows for the simplest setup. The model can run on CPU; an NVIDIA GPU is not required for this demonstration. CPU inference may take several seconds per image depending on image size and computer performance.

## 2. Create and activate a virtual environment

Open PowerShell in this project folder:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use this command for the current terminal session, then activate the environment again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## 3. Add the model weights

Download `solar_filament_yolo11n_seg_best.pt` from the Kaggle notebook Output panel (or extract it from the backup ZIP created by the notebook). Put the `.pt` file at:

```text
models/solar_filament_yolo11n_seg_best.pt
```

The model weights are not included in this starter ZIP.

## 4. Run the demo

```powershell
streamlit run app.py
```

A browser tab should open. Upload a solar image, choose a confidence threshold and inference size, then click **Run filament segmentation**. Download the annotated prediction from the page.

For an ordinary 8 GB RAM laptop, start with inference size 768. Use 1024 to more closely match the competition inference configuration, accepting that it can be slower.

## Project structure

```text
solar_filament_demo/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── models/
│   └── README.txt
└── outputs/
```

## Method

1. Load solar images and instance annotations from the competition dataset.
2. Split by unique image filename into 600 training and 107 validation images.
3. Fine-tune a pretrained YOLO11n instance-segmentation model for 25 epochs at image size 1024 with batch size 4 on a Tesla T4.
4. Run inference on validation and test images; apply a confidence threshold of 0.35 for the submitted baseline.
5. Remove pixel overlaps from submission instances, assigning overlapping pixels to the earlier/higher-confidence instance, and submit the resulting masks as RLE.

## Limitations

- The official score of 0.26 is a modest baseline, not a claim of state-of-the-art performance.
- Some faint, thin, or disconnected filament parts are missed; false positives also occur.
- A confidence threshold trades false positives against missed filaments.
- Pixel-level overlap correction enforces non-overlap but can alter masks where two real filaments touch or cross.
- This model is an educational research demo, not an operational scientific instrument.

## Dataset and model provenance

The image data and annotations came from the Solar Filament Segmentation Challenge 2026 dataset on Kaggle. Follow the competition rules and dataset licence when redistributing images, annotations, or model weights. The dataset is not bundled in this repository.
