from __future__ import annotations

import io
import time
from pathlib import Path

import numpy as np
import streamlit as st
from PIL import Image
from ultralytics import YOLO


PROJECT_DIR = Path(__file__).resolve().parent
MODEL_PATH = PROJECT_DIR / "models" / "solar_filament_yolo11n_seg_best.pt"

st.set_page_config(
    page_title="Solar Filament Segmentation",
    page_icon="☀️",
    layout="wide",
)

st.title("Solar Filament Detection & Segmentation")
st.write(
    "Upload a solar image to detect candidate filament structures and display "
    "the model's instance masks. This is an experimental student project, "
    "not an operational solar-monitoring tool."
)

with st.expander("About this project", expanded=False):
    st.markdown(
        """
        **Model:** YOLO11n instance segmentation, fine-tuned in Kaggle.

        **Training setup:** 600 training images, 107 validation images, 25 epochs,
        1024-pixel training image size, batch size 4.

        **Reported validation metrics:** box mAP@50 0.612; mask mAP@50 0.622;
        mask mAP@50–95 0.222. The initial competition submission received an
        official score of 0.26. These are different metrics and should not be
        compared as if they measured the same thing.

        **Known limitations:** faint and very small filaments may be missed;
        some false positives occur; performance depends on image quality and
        inference settings. The official hidden-test score is not a guarantee
        of performance on new images.
        """
    )

if not MODEL_PATH.is_file():
    st.error("Model weights are missing.")
    st.markdown(
        "Place the downloaded file **`solar_filament_yolo11n_seg_best.pt`** "
        "inside the project's **`models`** folder, then reload this page."
    )
    st.code(str(MODEL_PATH), language="text")
    st.stop()


@st.cache_resource(show_spinner="Loading the trained model...")
def load_model(model_path: str) -> YOLO:
    return YOLO(model_path)


uploaded_file = st.file_uploader(
    "Choose a solar image",
    type=["png", "jpg", "jpeg", "tif", "tiff", "bmp"],
)

left, right = st.columns(2)
with left:
    confidence = st.slider(
        "Detection confidence threshold",
        min_value=0.05,
        max_value=0.90,
        value=0.35,
        step=0.05,
        help="Higher values usually reduce false positives but may miss faint filaments.",
    )
with right:
    image_size = st.select_slider(
        "Inference image size",
        options=[512, 640, 768, 1024],
        value=768,
        help="768 is a practical CPU demo setting. Choose 1024 to more closely match training inference.",
    )

if uploaded_file is not None:
    try:
        original = Image.open(uploaded_file).convert("RGB")
        original_array = np.asarray(original)
    except Exception as exc:
        st.error(f"Could not read this image: {exc}")
        st.stop()

    st.caption(f"Image dimensions: {original.width} × {original.height} pixels")

    run_prediction = st.button("Run filament segmentation", type="primary")

    if run_prediction:
        try:
            model = load_model(str(MODEL_PATH))
            start_time = time.perf_counter()
            with st.spinner("Running inference on the CPU..."):
                results = model.predict(
                    source=original_array,
                    imgsz=int(image_size),
                    conf=float(confidence),
                    iou=0.70,
                    max_det=100,
                    retina_masks=True,
                    device="cpu",
                    verbose=False,
                )
            elapsed = time.perf_counter() - start_time
            result = results[0]

            # Ultralytics plot() returns a BGR image; Streamlit expects RGB.
            annotated_bgr = result.plot()
            annotated_rgb = annotated_bgr[:, :, ::-1].copy()

            instance_count = 0
            if result.masks is not None:
                instance_count = len(result.masks.data)
            elif result.boxes is not None:
                instance_count = len(result.boxes)

            metric1, metric2, metric3 = st.columns(3)
            metric1.metric("Predicted instances", instance_count)
            metric2.metric("Inference time", f"{elapsed:.1f} s")
            metric3.metric("Confidence threshold", f"{confidence:.2f}")

            original_col, result_col = st.columns(2)
            with original_col:
                st.subheader("Original image")
                st.image(original, use_container_width=True)
            with result_col:
                st.subheader("Predicted masks")
                st.image(annotated_rgb, use_container_width=True)

            output = io.BytesIO()
            Image.fromarray(annotated_rgb).save(output, format="PNG")
            safe_stem = Path(uploaded_file.name).stem or "solar_image"
            st.download_button(
                "Download annotated result",
                data=output.getvalue(),
                file_name=f"{safe_stem}_segmentation.png",
                mime="image/png",
            )

            if instance_count == 0:
                st.warning(
                    "No masks were returned at this confidence threshold. "
                    "Try lowering the threshold."
                )
        except Exception as exc:
            st.exception(exc)
else:
    st.info("Upload a solar image above to begin.")

st.divider()
st.caption(
    "Project note: predictions are model outputs and may contain omissions or false positives. "
    "The validation and competition scores are documented in the README."
)
